from fontTools.ttLib import TTFont
import sys

font_path = r'C:\Users\Username\Desktop\program\python\poker game\draw-and-win\NotoSansTC-VF.ttf'
f = TTFont(font_path)
cmap = f.getBestCmap()

has_zhu = 0x4E3B in cmap   # 主
has_dan = 0x55AE in cmap   # 單

with open('verify_result.txt', 'w', encoding='utf-8') as out:
    out.write(f'主 (0x4E3B) in cmap: {has_zhu}\n')
    out.write(f'單 (0x55AE) in cmap: {has_dan}\n')
    out.write(f'Total glyphs in cmap: {len(cmap)}\n')

sys.exit(0 if (has_zhu and has_dan) else 1)
