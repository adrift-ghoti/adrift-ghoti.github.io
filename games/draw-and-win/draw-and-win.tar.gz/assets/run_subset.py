import sys
sys.argv = [
    'pyftsubset',
    r'C:\Windows\Fonts\NotoSansTC-VF.ttf',
    '--text-file=subset_chars.txt',
    '--layout-features=*',
    '--output-file=NotoSansTC-VF.ttf',
]
from fontTools.subset import main
main()
